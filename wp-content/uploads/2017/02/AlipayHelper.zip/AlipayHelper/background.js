jump_url=false;
status_flag=false;
chrome.webRequest.onBeforeRequest.addListener(function(request)
{
	if(jump_url)
	{
		if(status_flag)
		{
			status_flag=false;
			var jump_url_=jump_url;
			jump_url=false;
			return {
				redirectUrl: jump_url_
			};
		}
		else
		{
			status_flag=true;
		}
	}
},
{
	urls: [
		'https://110.alipay.com/cert/certCheck.htm*'
	]
},['blocking']);

chrome.webRequest.onBeforeRequest.addListener(function(request)
{
	if(request.method=='GET')
	{
		var match=request.url.match(/(^|\?|&)goto=([^&]*)(&|$)/);
		if(match)
		{
			jump_url=unescape(match[2]);
		}
	}
},
{
	urls: [
		'https://authzth.alipay.com/login/certCheck.htm*'
	]
},['blocking']);

chrome.webRequest.onBeforeRequest.addListener(function(request)
{
	if(request.url==jump_url)
	{
		return {
			redirectUrl: 'https://110.alipay.com/cert/certCheck.htm?_xbox=true'
		};
	}
},
{
	urls: [
		'<all_urls>'
	]
},['blocking']);
